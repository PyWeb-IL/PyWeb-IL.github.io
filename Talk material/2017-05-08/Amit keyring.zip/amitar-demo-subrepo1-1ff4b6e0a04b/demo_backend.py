from keyring.util import properties
from keyring.backend import KeyringBackend
from keyring.errors import ExceptionRaisedContext

try:
    import gnupg
except ImportError:
    pass


class DemoBackend(KeyringBackend):
    "demo backend (uses a dict)"

    @classmethod
    def _has_gnupg(cls):
        with ExceptionRaisedContext() as exc:
            gnupg.GPG()
        return not bool(exc)
    
    @properties.ClassProperty
    @classmethod
    def priority(cls):
        if not cls._has_gnupg():
            raise RuntimeError("gnupg required")
        return 3

    def __init__(self):
        self.data = {}
    
    def set_password(self, servicename, username, password):
        self.data.setdefault(servicename, {})[username] = password
    
    def get_password(self, servicename, username):
        return self.data.get(servicename,{}).get(username)

    def delete_password(self, servicename, username):
        s = self.data.get(servicename)
        if s is not None:
            if username in s:
                del s[username]
                if not s:
                    del self.data[servicename]

    
