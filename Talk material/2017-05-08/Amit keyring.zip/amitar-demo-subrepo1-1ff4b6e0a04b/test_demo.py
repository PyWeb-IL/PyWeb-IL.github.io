#import pytest
from keyring.tests.test_backend import BackendBasicTests

class DemoTests(BackendBasicTests):
    pass
