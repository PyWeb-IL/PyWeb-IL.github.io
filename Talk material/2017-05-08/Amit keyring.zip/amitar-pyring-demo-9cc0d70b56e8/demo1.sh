emacsclient ~/.hgrc #disable the keyring extension]

#cd ~/src/pyring-demo
ls -l
hg status --all

touch newfile1; hg add newfile1
hg ci -m “added a new file”
hg push

#[every push and pull!, also:]
#[explain about subrepos]
thg

cd ..
hg clone https://bitbucket.org/amitar/pyring-demo test1
rm -rf test1

emacsclient ~/.hgrc #enable the keyring extension
hg clone https://bitbucket.org/amitar/pyring-demo test2
